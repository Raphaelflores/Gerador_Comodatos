/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facilitador;

import java.io.File;
import java.util.List;
import javafx.scene.text.Text;
import javax.xml.bind.JAXBElement;

/**
 *
 * @author RaphaelFloresdaCosta
 */
public class Facilitador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Load document
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new File("FileFormat.docx"));
// Load main document part
MainDocumentPart mainDocumentPart = wordMLPackage.getMainDocumentPart();
// Extract nodes
String textNodesXPath = "//w:t";
List<Object> textNodes= mainDocumentPart.getJAXBNodesViaXPath(textNodesXPath, true);
// Print text
for (Object obj : textNodes) {
  Text text = (Text) ((JAXBElement) obj).getValue();
  String textValue = text.getValue();
  System.out.println(textValue);
}

    }
    
}
