/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facilitador;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 *
 * @author RaphaelFloresdaCosta
 */

public class PegaArquivo {
    /*
    public static file(){
    FileReader fr = null;
    try {
    FileReader fr = new FileReader("C:\\Users\\RaphaelFloresdaCosta\\Daniele Banco\\Daniele Banco - Documentos\\ti\\2024\\Termo de Responsabilidade\\NOVO INSTRUMENTO PARTICULAR DE COMODATO.docx");
    }catch(FileNotFoundException e){
    e.printStackTrace();
        }
        return fr;
    } 
}

*/
    public static FileReader getFile() {
        FileReader fr = null;
        try {
            fr = new FileReader("C:\\Users\\RaphaelFloresdaCosta\\Daniele Banco\\Daniele Banco - Documentos\\ti\\2024\\Termo de Responsabilidade\\NOVO INSTRUMENTO PARTICULAR DE COMODATO.docx");
            System.out.println(fr.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return fr;
    }
}